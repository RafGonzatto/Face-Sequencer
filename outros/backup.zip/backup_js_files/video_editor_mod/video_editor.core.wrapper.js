// video_editor.core.wrapper.js - safe loader that ignores corrupted monolith and loads modular core
(function () {
  if (window.VideoEditorCoreExt) {
    return;
  }
  const basePath = "static/js/video_editor_mod/video-editor_core/";
  // Load order matters: base -> history -> transcript -> progress -> subtitles -> alignment -> index (composition)
  const files = [
    "core_base.js",
    "core_history.js",
    "core_transcript.js",
    "core_progress.js",
    "core_subtitles.js",
    "core_alignment_enhanced.js",
    "index.js",
  ];
  let i = 0;
  function next() {
    if (i >= files.length) {
      console.log("[Wrapper] Modular core loaded");
      // After core mixins loaded, ensure UI/media/subtitles + module class if ESM index.js (outside this pipeline) not used
      setTimeout(() => {
        if (!window.VideoEditorModule && window.VideoEditorCoreExt) {
          // Dynamically load UI/media/subtitles (non-ESM) if missing
          const extra = [
            "static/js/video_editor_mod/video_editor.ui.v2.js",
            "static/js/video_editor_mod/video_editor.media.js",
            "static/js/video_editor_mod/video_editor.subtitles.js",
          ];
          let k = 0;
          const loadExtra = () => {
            if (k >= extra.length) {
              try {
                if (
                  window.attachUI &&
                  window.attachMedia &&
                  window.attachSubtitles
                ) {
                  class AssembledVideoEditor extends window.VideoEditorCoreExt {
                    constructor(appRef) {
                      const maybe = super(appRef);
                      const finalize = (inst) => {
                        window.attachUI(inst);
                        window.attachMedia(inst);
                        window.attachSubtitles(inst);
                        inst.bindEvents && inst.bindEvents();
                        return inst;
                      };
                      if (maybe && typeof maybe.then === "function") {
                        maybe.then(finalize);
                        return maybe;
                      }
                      return finalize(this);
                    }
                  }
                  window.VideoEditorModule = AssembledVideoEditor;
                  console.log(
                    "[Wrapper] AssembledVideoEditor registered (legacy path)"
                  );
                }
              } catch (e) {
                console.warn("[Wrapper] Assembly failure", e);
              }
              return;
            }
            const sc = document.createElement("script");
            sc.src = extra[k] + "?va=1";
            sc.onload = () => {
              k++;
              loadExtra();
            };
            sc.onerror = () => {
              console.warn("[Wrapper] Failed to load extra", extra[k]);
              k++;
              loadExtra();
            };
            document.head.appendChild(sc);
          };
          loadExtra();
        }
      }, 120);
      return;
    }
    const s = document.createElement("script");
    s.src = basePath + files[i];
    s.onload = () => {
      i++;
      next();
    };
    s.onerror = () => {
      console.error("[Wrapper] Falha ao carregar", files[i]);
      i++;
      next();
    };
    document.head.appendChild(s);
  }
  next();

  // Defensive: after core sequence, verify that index.js registered VideoEditorModule; if not, attempt manual assembly
  setTimeout(() => {
    if (!window.VideoEditorModule) {
      console.warn(
        "[Wrapper][Fallback] VideoEditorModule not present after core load; injecting UI/media/subtitles manually"
      );
      // Load standalone modular files (non-tree-shaken) with cache-bust
      const extraFiles = [
        "static/js/video_editor_mod/video_editor.core.js",
        "static/js/video_editor_mod/video_editor.ui.v2.js",
        "static/js/video_editor_mod/video_editor.media.js",
        "static/js/video_editor_mod/video_editor.subtitles.js",
      ];
      let j = 0;
      function loadExtra() {
        if (j >= extraFiles.length) {
          try {
            if (
              window.VideoEditorCoreExt &&
              !window.VideoEditorModule &&
              window.attachUI &&
              window.attachMedia &&
              window.attachSubtitles
            ) {
              class FallbackVideoEditor extends window.VideoEditorCoreExt {
                constructor(appRef) {
                  const maybe = super(appRef);
                  const finalize = (inst) => {
                    window.attachUI(inst);
                    window.attachMedia(inst);
                    window.attachSubtitles(inst);
                    inst.bindEvents && inst.bindEvents();
                    return inst;
                  };
                  if (maybe && typeof maybe.then === "function") {
                    maybe.then(finalize);
                    return maybe;
                  }
                  return finalize(this);
                }
              }
              window.VideoEditorModule = FallbackVideoEditor;
              console.log("[Wrapper][Fallback] FallbackVideoEditor registered");
            }
          } catch (e) {
            console.warn("[Wrapper][Fallback] assembly failed", e);
          }
          return;
        }
        const sc = document.createElement("script");
        sc.src = extraFiles[j] + "?vf=1";
        sc.onload = () => {
          j++;
          loadExtra();
        };
        sc.onerror = () => {
          console.warn("[Wrapper][Fallback] failed extra", extraFiles[j]);
          j++;
          loadExtra();
        };
        document.head.appendChild(sc);
      }
      loadExtra();
    }
  }, 1800);
})();

// Inline minimal UI v2 fallback (only if attachUI not already defined)
(function () {
  if (typeof window === "undefined") return;
  if (window.attachUI) return; // already present
  function attachUI(self) {
    console.log("[Wrapper][InlineUIv2] Minimal attachUI applied");
    self.bindEvents = function () {
      try {
        const controls = document.querySelector(
          ".video-controls .playback-controls"
        );
        if (controls && !document.getElementById("toggleOverlayEditBtn")) {
          const btn = document.createElement("button");
          btn.id = "toggleOverlayEditBtn";
          btn.className = "btn btn-sm";
          btn.textContent = "Edit Overlay";
          btn.disabled = true;
          btn.style.minWidth = "90px";
          btn.addEventListener("click", () => {
            const overlay =
              document.getElementById("subtitleOverlay") ||
              document.getElementById("veSubtitleOverlay");
            if (!overlay) return;
            if (!overlay.isContentEditable) {
              overlay.contentEditable = "true";
              overlay.dataset.prevOutline = overlay.style.outline || "none";
              overlay.style.outline = "2px dashed #4da3ff";
              btn.textContent = "Save Text";
              overlay.focus();
            } else {
              overlay.contentEditable = "false";
              overlay.style.outline = overlay.dataset.prevOutline || "none";
              btn.textContent = "Edit Overlay";
              try {
                const subs = self.subtitles || [];
                const video = document.getElementById("videoPreview");
                if (video && subs.length) {
                  const t = video.currentTime * 1000;
                  const active = subs.find(
                    (s) => t >= s.start_ms && t <= s.end_ms
                  );
                  if (active) {
                    active.text = overlay.textContent.trim();
                    self.renderSubtitleSegments &&
                      self.renderSubtitleSegments();
                  }
                }
              } catch (e) {}
            }
          });
          controls.appendChild(btn);
        }
      } catch (e) {}
    };
  }
  window.attachUI = attachUI;
})();
