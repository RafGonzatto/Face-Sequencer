// Compatibilidade com navegadores
// Versão modificada para resolver o erro "Unexpected token 'export'"
// Original: export function attachSubtitles(self) {...}

// Subtitles module: generation, alignment, optimization & presets
function attachSubtitles(self) {
  // ---- Button Wiring (idempotent) ----
  const wireActionButtons = () => {
    // Generate Subtitles
    if (self.generateSubtitlesBtn && !self.generateSubtitlesBtn._veBound) {
      self.generateSubtitlesBtn._veBound = true;
      self.generateSubtitlesBtn.addEventListener("click", (e) => {
        e.preventDefault();
        self.generateSubtitles();
      });
    }

    // Export Button
    if (self.exportBtn && !self.exportBtn._veBound) {
      self.exportBtn._veBound = true;
      self.exportBtn.addEventListener("click", (e) => {
        e.preventDefault();
        self.exportVideo();
      });
    }
  };

  // Inicialização e registro de eventos
  self.setupSubtitles = function () {
    console.log("Setting up subtitle module...");
    wireActionButtons();

    // Estado dos legendas
    self.subtitles = [];
    self.subtitleMarkers = [];
  };

  // Gerar legendas
  self.generateSubtitles = function () {
    if (!self.videoPreview && !self.videoElement) {
      console.error("No video loaded");
      return;
    }

    const video = self.videoPreview || self.videoElement;

    // Mostrar indicador de carregamento
    self.showLoading("Generating subtitles...");

    // Obter texto para legendas
    const transcript = self.getTranscript();

    if (!transcript) {
      self.hideLoading();
      alert("Please enter a transcript text first");
      return;
    }

    // Simular processo de geração de legendas (normalmente seria uma chamada de API)
    setTimeout(() => {
      // Gerar legendas de exemplo
      const duration = video.duration || 60;
      const words = transcript.split(/\s+/);
      const wordDuration = duration / words.length;

      let currentTime = 0;
      const subs = [];

      for (let i = 0; i < words.length; i += 5) {
        const segment = words.slice(i, i + 5).join(" ");
        const startTime = currentTime;
        const endTime = currentTime + wordDuration * 5;

        subs.push({
          id: i / 5,
          text: segment,
          startTime,
          endTime,
        });

        currentTime = endTime;
      }

      // Atualizar legendas
      self.subtitles = subs;

      // Renderizar legendas
      self.renderSubtitles();

      // Ocultar indicador de carregamento
      self.hideLoading();
    }, 1500);
  };

  // Obter texto do elemento de transcrição
  self.getTranscript = function () {
    const textArea = document.getElementById("videoTranscript");
    return textArea ? textArea.value : "";
  };

  // Renderizar legendas na interface
  self.renderSubtitles = function () {
    if (!self.subtitles || self.subtitles.length === 0) {
      console.warn("No subtitles to render");
      return;
    }

    // Limpar lista de legendas
    if (self.subtitleList) {
      self.subtitleList.innerHTML = "";
    } else {
      console.warn("Subtitle list container not found");
      return;
    }

    // Limpar marcadores existentes
    self.clearSubtitleMarkers();

    // Criar elementos de legenda
    self.subtitles.forEach((subtitle) => {
      // Criar item de legenda
      const item = document.createElement("div");
      item.className = "subtitle-item";
      item.dataset.id = subtitle.id;

      // Formatar tempo
      const startFormatted = self.formatTime(subtitle.startTime);
      const endFormatted = self.formatTime(subtitle.endTime);

      // Estrutura HTML do item
      item.innerHTML = `
        <div class="subtitle-time">${startFormatted} - ${endFormatted}</div>
        <div class="subtitle-text">${subtitle.text}</div>
        <div class="subtitle-actions">
          <button class="btn btn-xs btn-outline edit-subtitle-btn">
            <i class="fas fa-edit"></i>
          </button>
          <button class="btn btn-xs btn-outline delete-subtitle-btn">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      `;

      // Adicionar à lista
      self.subtitleList.appendChild(item);

      // Adicionar evento de clique para navegar para o tempo da legenda
      item.addEventListener("click", () => {
        self.seekToTime(subtitle.startTime);
      });

      // Adicionar evento para botão de edição
      const editBtn = item.querySelector(".edit-subtitle-btn");
      editBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        self.editSubtitle(subtitle);
      });

      // Adicionar evento para botão de exclusão
      const deleteBtn = item.querySelector(".delete-subtitle-btn");
      deleteBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        self.deleteSubtitle(subtitle);
      });

      // Criar marcador na timeline
      self.createSubtitleMarker(subtitle);
    });

    // Ativar botão de exportação
    if (self.exportBtn) {
      self.exportBtn.disabled = false;
    }

    // Atualizar estatísticas
    self.updateStats();
  };

  // Criar marcador de legenda na timeline
  self.createSubtitleMarker = function (subtitle) {
    if (!self.timeline) return;

    const video = self.videoPreview || self.videoElement;
    if (!video) return;

    const duration = video.duration || 60;
    const startPercent = (subtitle.startTime / duration) * 100;
    const endPercent = (subtitle.endTime / duration) * 100;
    const width = endPercent - startPercent;

    const marker = document.createElement("div");
    marker.className = "timeline-subtitle-marker";
    marker.style.left = startPercent + "%";
    marker.style.width = width + "%";
    marker.dataset.id = subtitle.id;

    // Adicionar à timeline
    const timelineMarkers =
      self.timeline.querySelector(".timeline-markers") || self.timeline;
    timelineMarkers.appendChild(marker);

    // Armazenar referência ao marcador
    self.subtitleMarkers.push(marker);
  };

  // Limpar marcadores de legenda
  self.clearSubtitleMarkers = function () {
    self.subtitleMarkers.forEach((marker) => {
      if (marker && marker.parentNode) {
        marker.parentNode.removeChild(marker);
      }
    });
    self.subtitleMarkers = [];
  };

  // Navegar para um tempo específico no vídeo
  self.seekToTime = function (time) {
    const video = self.videoPreview || self.videoElement;
    if (video) {
      video.currentTime = time;
    }
  };

  // Editar legenda
  self.editSubtitle = function (subtitle) {
    // Implementação simplificada de edição
    const newText = prompt("Edit subtitle text:", subtitle.text);
    if (newText !== null) {
      subtitle.text = newText;
      self.renderSubtitles();
    }
  };

  // Excluir legenda
  self.deleteSubtitle = function (subtitle) {
    // Confirmar exclusão
    if (confirm("Are you sure you want to delete this subtitle?")) {
      self.subtitles = self.subtitles.filter((s) => s.id !== subtitle.id);
      self.renderSubtitles();
    }
  };

  // Exportar vídeo com legendas
  self.exportVideo = function () {
    if (!self.subtitles || self.subtitles.length === 0) {
      alert("Please generate subtitles first");
      return;
    }

    // Mostrar indicador de progresso
    self.showLoading("Exporting video with subtitles...");

    // Simular processo de exportação
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      if (progress > 100) {
        clearInterval(interval);
        self.hideLoading();
        alert("Video export complete!");
      } else {
        self.updateProgress(progress);
      }
    }, 500);
  };

  // Mostrar indicador de carregamento
  self.showLoading = function (message) {
    let loading = document.querySelector(".loading-indicator");

    if (!loading) {
      loading = document.createElement("div");
      loading.className = "loading-indicator";
      loading.innerHTML = `
        <div class="spinner"></div>
        <div class="message">${message || "Loading..."}</div>
        <div class="progress-bar">
          <div class="progress-fill"></div>
        </div>
      `;

      const container = self.videoContainer || document.body;
      container.appendChild(loading);
    } else {
      const messageEl = loading.querySelector(".message");
      if (messageEl) {
        messageEl.textContent = message || "Loading...";
      }
      loading.style.display = "flex";
    }
  };

  // Ocultar indicador de carregamento
  self.hideLoading = function () {
    const loading = document.querySelector(".loading-indicator");
    if (loading) {
      loading.style.display = "none";
    }
  };

  // Atualizar progresso
  self.updateProgress = function (percent) {
    const loading = document.querySelector(".loading-indicator");
    if (loading) {
      const fill = loading.querySelector(".progress-fill");
      if (fill) {
        fill.style.width = percent + "%";
      }

      const message = loading.querySelector(".message");
      if (message) {
        message.textContent = `Exporting video... ${percent}%`;
      }
    }
  };

  // Atualizar estatísticas
  self.updateStats = function () {
    const statsElement = document.getElementById("videoEditorStats");
    if (statsElement && self.subtitles) {
      const count = self.subtitles.length;
      const duration = self.videoElement?.duration || 0;
      const formattedDuration = self.formatTime(duration);
      statsElement.textContent = `${count} seg • ${formattedDuration}`;
    }
  };

  // Formatar tempo em formato mm:ss
  self.formatTime = function (seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
  };

  // Inicializar módulo
  self.setupSubtitles();
}

// Expose para uso global
window.VideoEditorSubtitles = {
  attachSubtitles: attachSubtitles,
};
