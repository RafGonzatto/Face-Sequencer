// Compatibilidade com navegadores
// Versão modificada para resolver o erro "Unexpected token 'export'"
// Original: export function attachMedia(self) {...}

// Media module: video/audio handling and transport
function attachMedia(self) {
  // Extend bindEvents to include media-specific events
  const origBind = self.bindEvents;

  // Helper to (re)bind video element events when it becomes available
  self._bindVideoPreviewEvents = function (force) {
    if (!self.videoPreview) {
      self.videoPreview =
        document.getElementById("videoPreview") || self.videoPreview;
    }
    if (!self.videoElement) {
      self.videoElement =
        document.getElementById("videoElement") || self.videoElement;
    }

    if (!self.videoElement && !self.videoPreview) {
      console.warn("Video elements not found");
      return;
    }

    // Usar o elemento que estiver disponível
    const video = self.videoPreview || self.videoElement;

    if (!video || (video._veBound && !force)) return;

    console.log("Binding video element events", video);
    video._veBound = true;

    // Eventos de vídeo
    video.addEventListener("timeupdate", () => self.handleTimeUpdate());
    video.addEventListener("play", () => self.handlePlay());
    video.addEventListener("pause", () => self.handlePause());
    video.addEventListener("ended", () => self.handleEnded());
  };

  // Substituir o método bindEvents para incluir eventos de mídia
  self.bindEvents = function () {
    // Chamar o método original primeiro
    if (origBind) origBind.call(self);

    // Adicionar eventos específicos de mídia
    const videoPlayPauseBtn = document.getElementById("videoPlayPauseBtn");
    if (videoPlayPauseBtn) {
      videoPlayPauseBtn.addEventListener("click", () => self.togglePlayPause());
    }

    const loadVideoBtn = document.getElementById("loadVideoBtn");
    if (loadVideoBtn) {
      loadVideoBtn.addEventListener("click", () => self.openVideoFileDialog());
    }

    // Vincular eventos ao elemento de vídeo
    self._bindVideoPreviewEvents();
  };

  // Métodos de controle de mídia

  // Alternar entre reprodução e pausa
  self.togglePlayPause = function () {
    if (!self.videoElement && !self.videoPreview) return;

    const video = self.videoPreview || self.videoElement;

    if (video.paused || video.ended) {
      self.play();
    } else {
      self.pause();
    }
  };

  // Reproduzir vídeo
  self.play = function () {
    if (!self.videoElement && !self.videoPreview) return;

    const video = self.videoPreview || self.videoElement;
    const playPauseBtn = document.getElementById("videoPlayPauseBtn");

    video.play();

    if (playPauseBtn) {
      playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
    }
  };

  // Pausar vídeo
  self.pause = function () {
    if (!self.videoElement && !self.videoPreview) return;

    const video = self.videoPreview || self.videoElement;
    const playPauseBtn = document.getElementById("videoPlayPauseBtn");

    video.pause();

    if (playPauseBtn) {
      playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
    }
  };

  // Manipuladores de eventos

  // Atualização de tempo
  self.handleTimeUpdate = function () {
    if (!self.videoElement && !self.videoPreview) return;

    const video = self.videoPreview || self.videoElement;

    // Atualizar timeline
    if (self.timelineProgress) {
      const progress = (video.currentTime / video.duration) * 100;
      self.timelineProgress.style.width = progress + "%";
    }

    // Atualizar marcador
    if (self.timelineMarker) {
      const position = (video.currentTime / video.duration) * 100;
      self.timelineMarker.style.left = position + "%";
    }
  };

  // Evento de reprodução
  self.handlePlay = function () {
    const playPauseBtn = document.getElementById("videoPlayPauseBtn");

    if (playPauseBtn) {
      playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
    }
  };

  // Evento de pausa
  self.handlePause = function () {
    const playPauseBtn = document.getElementById("videoPlayPauseBtn");

    if (playPauseBtn) {
      playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
    }
  };

  // Evento de fim de reprodução
  self.handleEnded = function () {
    const playPauseBtn = document.getElementById("videoPlayPauseBtn");

    if (playPauseBtn) {
      playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
    }
  };

  // Abrir diálogo para selecionar arquivo de vídeo
  self.openVideoFileDialog = function () {
    if (!self.videoInput) {
      self.videoInput = document.createElement("input");
      self.videoInput.type = "file";
      self.videoInput.accept = "video/*";
      self.videoInput.style.display = "none";

      self.videoInput.addEventListener("change", (e) => {
        if (e.target.files.length > 0) {
          const file = e.target.files[0];
          self.loadVideoFile(file);
        }
      });

      document.body.appendChild(self.videoInput);
    }

    self.videoInput.click();
  };

  // Carregar arquivo de vídeo
  self.loadVideoFile = function (file) {
    if (!self.videoElement && !self.videoPreview) return;

    const video = self.videoPreview || self.videoElement;

    // Revogar URL anterior se existir
    if (self._videoObjectURL) {
      URL.revokeObjectURL(self._videoObjectURL);
    }

    // Criar URL para o arquivo
    self._videoObjectURL = URL.createObjectURL(file);
    video.src = self._videoObjectURL;

    // Ativar controles de vídeo
    const exportBtn = document.getElementById("exportSubtitledVideoBtn");
    const generateBtn = document.getElementById("generateSubtitlesBtn");

    if (exportBtn) exportBtn.disabled = false;
    if (generateBtn) generateBtn.disabled = false;

    console.log("Video file loaded:", file.name);
  };
}

// Expose para uso global
window.VideoEditorMedia = {
  attachMedia: attachMedia,
};
