// Compatibilidade com navegadores
// Versão modificada para resolver o erro "Unexpected token 'export'"
// Original: export function attachUI(self) {...}

// UI module: visual DOM interactions & subtitle list/timeline segment operations
function attachUI(self) {
  // Rebind the original bindEvents logic (UI parts only)
  self.bindEvents = function () {
    console.log("🔧 VideoEditor(UI) - Binding events...");
    // Mode buttons
    if (self.faceAnimationMode) {
      self.faceAnimationMode.addEventListener("click", () =>
        self.switchToFaceAnimationMode()
      );
    }
    if (self.videoEditorMode) {
      self.videoEditorMode.addEventListener("click", (e) => {
        e.preventDefault();
        self.switchToVideoEditorMode();
      });
    }

    // Register utility handlers
    self._setupCommonEvents && self._setupCommonEvents();
    self._bindVideoPreviewEvents && self._bindVideoPreviewEvents();

    // Update stats/UI
    self.updateStats();
  };

  // UI setup for new instances
  self.setupVideoEditorInterface = function () {
    console.log("🔧 VideoEditor(UI) - Setting up interface...");

    // Common UI elements
    self.setupCommonElements();

    // Setup left panel
    self.setupLeftPanel();

    // Setup right panel
    self.setupRightPanel();

    // Establish event listeners
    self.bindEvents();
  };

  // Setup common elements
  self.setupCommonElements = function () {
    // Main panels and containers
    self.videoEditorInterface = document.getElementById("videoEditorInterface");
    self.videoPanel = self.videoEditorInterface?.querySelector(".video-panel");
    self.subtitlePanel =
      self.videoEditorInterface?.querySelector(".subtitle-panel");
    self.videoContainer =
      self.videoEditorInterface?.querySelector(".video-container");

    // Video player
    self.videoElement = document.getElementById("videoElement");
    self.videoPreview = document.getElementById("videoPreview");

    // Timeline elements
    self.timeline = document.getElementById("videoTimeline");
    self.timelineProgress = document.getElementById("timelineProgress");
    self.timelineMarker = document.getElementById("timelineMarker");
  };

  // Setup left panel elements
  self.setupLeftPanel = function () {
    // Video controls
    self.loadVideoBtn = document.getElementById("loadVideoBtn");
    self.generateSubtitlesBtn = document.getElementById("generateSubtitlesBtn");
    self.exportBtn = document.getElementById("exportSubtitledVideoBtn");
    self.playPauseBtn = document.getElementById("videoPlayPauseBtn");

    // Timeline elements
    if (!self.timeline) {
      self.timeline = document.getElementById("videoTimeline");
    }
  };

  // Setup right panel elements
  self.setupRightPanel = function () {
    // Subtitle list
    self.subtitleList = document.getElementById("subtitleList");
  };

  // Navigation between modes
  self.switchToFaceAnimationMode = function () {
    console.log("Switching to Face Animation mode");
    const faceAnimationInterface = document.querySelector(
      "#faceAnimationInterface"
    );
    if (faceAnimationInterface) {
      faceAnimationInterface.style.display = "block";
    }

    const videoEditorInterface = document.querySelector(
      "#videoEditorInterface"
    );
    if (videoEditorInterface) {
      videoEditorInterface.style.display = "none";
    }

    // Update button states
    if (self.faceAnimationMode) self.faceAnimationMode.classList.add("active");
    if (self.videoEditorMode) self.videoEditorMode.classList.remove("active");

    // Update body class
    document.body.classList.remove("video-editor-active");

    // Save preference
    try {
      localStorage.setItem("faceSequencerMode", "face-animation");
    } catch (e) {}
  };

  self.switchToVideoEditorMode = function () {
    console.log("Switching to Video Editor mode");
    const faceAnimationInterface = document.querySelector(
      "#faceAnimationInterface"
    );
    if (faceAnimationInterface) {
      faceAnimationInterface.style.display = "none";
    }

    const videoEditorInterface = document.querySelector(
      "#videoEditorInterface"
    );
    if (videoEditorInterface) {
      videoEditorInterface.style.display = "flex";
    }

    // Update button states
    if (self.faceAnimationMode)
      self.faceAnimationMode.classList.remove("active");
    if (self.videoEditorMode) self.videoEditorMode.classList.add("active");

    // Update body class
    document.body.classList.add("video-editor-active");

    // Save preference
    try {
      localStorage.setItem("faceSequencerMode", "video-editor");
    } catch (e) {}
  };
}

// Expose para uso global
window.VideoEditorUI = {
  attachUI: attachUI,
};
