// core_base.js - foundational class & initialization
(function (global) {
  class VideoEditorCoreBase {
    constructor(appRef) {
      this.appRef = appRef || null;
      this._undoStack = [];
      this._redoStack = [];
      this._maxHistory = 200;
      this._videoScaleModes = ["fit", "fill", "1:1"];
      this._videoScaleIndex = 0;
      this.alignmentFps = 30;
      this.overlayLocked = false;
      this._initHiddenInputs();
      this._logInit();
    }
    _logInit() {
      console.log("[VideoEditorCoreBase] initialized");
    }
    _initHiddenInputs() {
      if (!document.getElementById("videoInput")) {
        const i = document.createElement("input");
        i.type = "file";
        i.id = "videoInput";
        i.style.display = "none";
        i.accept = ".mp4,.mov,.mkv,.webm,.avi,.m4v,video/*";
        document.body.appendChild(i);
        this.videoInput = i;
      }
    }
    formatTime(sec) {
      const m = Math.floor(sec / 60),
        s = Math.floor(sec % 60);
      return (
        m.toString().padStart(2, "0") + ":" + s.toString().padStart(2, "0")
      );
    }
    updateVideoTime() {
      /* hook in subclasses */
    }
    updatePlayButton() {
      /* hook in subclasses */
    }
    pushHistory(state) {
      if (!state) return;
      this._undoStack.push(JSON.stringify(state));
      if (this._undoStack.length > this._maxHistory) this._undoStack.shift();
      this._redoStack.length = 0;
    }
    undo() {
      if (!this._undoStack.length) return null;
      const cur = this._undoStack.pop();
      if (cur) this._redoStack.push(cur);
      return this._undoStack.length
        ? JSON.parse(this._undoStack[this._undoStack.length - 1])
        : null;
    }
    redo() {
      if (!this._redoStack.length) return null;
      const nxt = this._redoStack.pop();
      if (nxt) {
        this._undoStack.push(nxt);
        return JSON.parse(nxt);
      }
      return null;
    }
  }
  global.VideoEditorCoreBase = VideoEditorCoreBase;
})(window);
