// core_transcript.js - transcript input management mixin
(function (global) {
  function TranscriptMixin(Base) {
    return class extends Base {
      initTranscriptBindings() {
        this.videoTranscript =
          document.getElementById("videoTranscript") || this.videoTranscript;
        this._altTextInput =
          document.getElementById("altTextInput") ||
          this._altTextInput ||
          document.getElementById("textInput");
        if (!this.videoTranscript && !this._altTextInput) {
          const t = document.createElement("textarea");
          t.id = "altTextInput";
          t.placeholder = "Digite ou cole o texto";
          t.style.cssText =
            "min-height:80px;width:100%;box-sizing:border-box;margin:8px 0;";
          (
            document.getElementById("videoEditorInterface") || document.body
          ).prepend(t);
          this._altTextInput = t;
        }
        if (!this.getTranscriptText) {
          this.getTranscriptText = () =>
            (this.videoTranscript && this.videoTranscript.value) ||
            (this._altTextInput && this._altTextInput.value) ||
            "";
        }
        const charCounter = document.getElementById("transcriptCharCount");
        const updateCount = () => {
          if (charCounter) {
            const l = this.getTranscriptText().length;
            charCounter.textContent = l + " caractere" + (l === 1 ? "" : "s");
          }
        };
        [this.videoTranscript, this._altTextInput].forEach((el) => {
          if (el && !el._veBound) {
            el.addEventListener("input", () => {
              this._cachedTranscript = el.value;
              updateCount();
              // Refresh button enable/disable state when user edits text
              this.updateGenerateButton && this.updateGenerateButton();
            });
            el._veBound = true;
          }
        });
        updateCount();
        // Attempt to acquire action buttons if not yet set (late DOM insertion cases)
        if (!this.generateSubtitlesBtn)
          this.generateSubtitlesBtn =
            document.getElementById("generateSubtitlesBtn") ||
            this.generateSubtitlesBtn;
        if (!this.alignFromTranscriptBtn)
          this.alignFromTranscriptBtn =
            document.getElementById("alignFromTranscriptBtn") ||
            this.alignFromTranscriptBtn;
        // One more delayed refresh to cover dynamic templates
        setTimeout(
          () => this.updateGenerateButton && this.updateGenerateButton(),
          50
        );
      }
    };
  }
  global.TranscriptMixin = TranscriptMixin;
})(window);
