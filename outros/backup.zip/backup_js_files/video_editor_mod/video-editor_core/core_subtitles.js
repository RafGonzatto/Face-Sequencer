// core_subtitles.js - subtitle conversion & simple rendering
(function (global) {
  function SubtitlesMixin(Base) {
    return class extends Base {
      convertAlignmentToSubtitles(alignment) {
        if (!alignment) return [];
        const tokens = alignment.tokens || alignment;
        if (!Array.isArray(tokens)) return [];
        const MAX_GAP = 400,
          MAX_CHARS = 80;
        const segments = [];
        let cur = null;
        for (const tk of tokens) {
          const start =
            tk.start_ms != null ? tk.start_ms : (tk.start || 0) * 1000;
          const end = tk.end_ms != null ? tk.end_ms : (tk.end || 0) * 1000;
          const txt = (tk.text || tk.token || "").trim();
          if (!txt) continue;
          if (!cur) {
            cur = {
              id: segments.length + 1,
              text: txt,
              start_ms: Math.round(start),
              end_ms: Math.round(end),
            };
            continue;
          }
          const gap = start - cur.end_ms;
          const prospective =
            cur.text + (cur.text.endsWith(" ") ? "" : " ") + txt;
          if (gap < MAX_GAP && prospective.length < MAX_CHARS) {
            cur.text = prospective;
            cur.end_ms = Math.round(end);
          } else {
            segments.push(cur);
            cur = {
              id: segments.length + 1,
              text: txt,
              start_ms: Math.round(start),
              end_ms: Math.round(end),
            };
          }
        }
        if (cur) segments.push(cur);
        return segments;
      }
      renderSubtitleSegments() {
        const container =
          this.segmentsList ||
          document.getElementById("segmentsList") ||
          document.getElementById("subtitlesList");
        if (!container) return;
        container.innerHTML = "";
        if (!this.subtitles || !this.subtitles.length) {
          const d = document.createElement("div");
          d.className = "subtitle-empty";
          d.textContent = "Nenhuma legenda";
          container.appendChild(d);
          return;
        }
        this.subtitles.forEach((s, i) => {
          const row = document.createElement("div");
          row.className = "subtitle-segment-item";
          row.dataset.id = s.id;
          row.innerHTML = `<div class="seg-index">${
            i + 1
          }</div><div class="seg-times">${(s.start_ms / 1000).toFixed(2)} → ${(
            s.end_ms / 1000
          ).toFixed(2)}</div><div class="seg-text"><input type="text" value="${(
            s.text || ""
          ).replace(/"/g, "&quot;")}"></div>`;
          const input = row.querySelector("input");
          input.addEventListener("input", () => {
            s.text = input.value;
          });
          container.appendChild(row);
        });
      }
    };
  }
  global.SubtitlesMixin = SubtitlesMixin;
})(window);
