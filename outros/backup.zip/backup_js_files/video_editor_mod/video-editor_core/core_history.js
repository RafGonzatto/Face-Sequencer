// core_history.js - extended undo/redo batching
(function (global) {
  function HistoryMixin(Base) {
    return class extends Base {
      beginBatch() {
        if (this._historyBatch) {
          return;
        }
        this._historyBatch = [];
      }
      pushHistoryState(state) {
        if (this._historyBatch) {
          this._historyBatch.push(JSON.stringify(state));
        } else {
          this.pushHistory(state);
        }
      }
      commitBatch() {
        if (!this._historyBatch) return;
        if (this._historyBatch.length) {
          const last = this._historyBatch[this._historyBatch.length - 1];
          this._undoStack.push(last);
          if (this._undoStack.length > this._maxHistory)
            this._undoStack.shift();
          this._redoStack.length = 0;
        }
        this._historyBatch = null;
      }
      cancelBatch() {
        this._historyBatch = null;
      }
    };
  }
  global.HistoryMixin = HistoryMixin;
})(window);
