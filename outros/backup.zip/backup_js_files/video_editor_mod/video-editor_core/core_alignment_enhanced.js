// core_alignment_enhanced.js - streaming enhanced alignment logic extracted
(function (global) {
  function EnhancedAlignmentMixin(Base) {
    return class extends Base {
      async alignAudioEnhanced(filename, text, progressCb) {
        // Try streaming first
        try {
          const streamed = await this._alignEnhancedStreaming(
            filename,
            text,
            progressCb
          );
          if (streamed) return streamed;
        } catch (e) {
          console.warn("[Alignment] Streaming fallback -> classic", e);
        }
        return this._alignEnhancedClassic(filename, text, progressCb);
      }
      async _alignEnhancedClassic(filename, text, progressCb) {
        const resp = await fetch("/api/audio/align-enhanced", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ filename, text }),
        });
        if (!resp.ok)
          throw new Error("Falha no alinhamento (HTTP " + resp.status + ")");
        const data = await resp.json();
        if (!data || !data.alignment)
          throw new Error("Resposta de alinhamento inválida");
        progressCb && progressCb("Alinhamento concluído (fallback)");
        return data;
      }
      async _alignEnhancedStreaming(filename, text, progressCb) {
        const endpoint = "/api/audio/align-enhanced/stream";
        this._createProgressOverlay &&
          this._createProgressOverlay("Alinhando áudio (stream)");
        this._updatePhaseProgress && this._updatePhaseProgress(0);
        const resp = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ filename, text }),
        });
        if (!resp.ok) throw new Error("Streaming endpoint HTTP " + resp.status);
        if (!resp.body || !window.ReadableStream)
          throw new Error("Streaming não suportado neste browser");
        const reader = resp.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let finalPayload = null;
        let targetPct = 0;
        let lastPct = 0;
        const startedAt = performance.now();
        // Smooth animation
        const smoothStep = () => {
          if (targetPct < lastPct) targetPct = lastPct;
          const diff = targetPct - lastPct;
          if (diff > 0.05) {
            lastPct += diff * 0.18;
            this._updatePhaseProgress && this._updatePhaseProgress(lastPct);
            requestAnimationFrame(smoothStep);
          } else {
            lastPct = targetPct;
            this._updatePhaseProgress && this._updatePhaseProgress(lastPct);
          }
        };
        requestAnimationFrame(smoothStep);
        const phaseNames = {
          start: "Iniciando",
          precheck: "Pré-checagem",
          load_audio: "Carregando áudio",
          decode: "Decodificando",
          model_load_start: "Carregando modelo",
          model_load_done: "Modelo pronto",
          tokens_partial: "Transcrevendo",
          complete: "Concluído",
        };
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let idx;
          while ((idx = buffer.indexOf("\n\n")) !== -1) {
            const chunk = buffer.slice(0, idx).trim();
            buffer = buffer.slice(idx + 2);
            if (!chunk.startsWith("data:")) continue;
            try {
              const payload = JSON.parse(chunk.substring(5).trim());
              const evt = payload.event;
              const data = payload.data || {};
              const rawPct =
                data.dynamic_progress_percent ?? data.progress_percent ?? 0;
              targetPct = Math.min(100, Math.max(0, rawPct));
              const phaseLabel = phaseNames[evt] || evt;
              progressCb &&
                progressCb(phaseLabel + " (" + rawPct.toFixed(0) + "%)");
              if (
                (evt === "tokens_partial" || evt === "transcribe") &&
                data.sent_tokens != null &&
                data.total_tokens != null
              ) {
                this._updateTokenCounter &&
                  this._updateTokenCounter(data.sent_tokens, data.total_tokens);
              }
              // ETA (simplificado)
              const elapsedMs = performance.now() - startedAt;
              let etaMs = null;
              if (rawPct > 1 && rawPct < 100) {
                const rate = elapsedMs / rawPct;
                etaMs = (100 - rawPct) * rate;
              }
              // Historical adjustment
              try {
                const histStr = localStorage.getItem("faceSeqAlignmentMetrics");
                if (histStr) {
                  const hist = JSON.parse(histStr);
                  if (hist?.avgTotalSeconds && rawPct > 2 && rawPct < 100) {
                    const est =
                      (hist.avgTotalSeconds * 1000 * (100 - rawPct)) / 100 -
                      elapsedMs;
                    if (est > 0) etaMs = est;
                  }
                }
              } catch (_) {}
              let etaText = "";
              if (etaMs !== null) {
                etaText = " • ETA ~" + (etaMs / 1000).toFixed(1) + "s";
              }
              this._updateProgressDetail &&
                this._updateProgressDetail(
                  phaseLabel + " • " + rawPct.toFixed(0) + "%" + etaText
                );
              if (evt === "complete") {
                finalPayload = data;
                try {
                  const metrics = data.metrics;
                  if (metrics?.total_seconds) {
                    let store = {
                      count: 1,
                      total: metrics.total_seconds,
                      avgTotalSeconds: metrics.total_seconds,
                    };
                    const prev = localStorage.getItem(
                      "faceSeqAlignmentMetrics"
                    );
                    if (prev) {
                      try {
                        const parsed = JSON.parse(prev);
                        if (parsed?.count != null && parsed?.total != null) {
                          store.count = parsed.count + 1;
                          store.total = parsed.total + metrics.total_seconds;
                          store.avgTotalSeconds = store.total / store.count;
                        }
                      } catch (_) {}
                    }
                    localStorage.setItem(
                      "faceSeqAlignmentMetrics",
                      JSON.stringify(store)
                    );
                  }
                } catch (_) {}
              } else if (evt === "error") {
                throw new Error(data.error || "Erro no alinhamento");
              }
            } catch (parseErr) {
              console.warn("[Alignment] Erro parse chunk", parseErr);
            }
          }
        }
        this._updatePhaseProgress && this._updatePhaseProgress(100);
        this._updateProgressDetail &&
          this._updateProgressDetail("Finalizando...");
        if (!finalPayload)
          throw new Error("Streaming não retornou payload final");
        this._removeProgressOverlay && this._removeProgressOverlay();
        const alignment = finalPayload.alignment || finalPayload;
        return { alignment, ...finalPayload };
      }
    };
  }
  global.EnhancedAlignmentMixin = EnhancedAlignmentMixin;
})(window);
