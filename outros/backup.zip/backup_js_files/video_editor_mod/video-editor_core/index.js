// index.js - compose modular core
(function (global) {
  const Base = global.VideoEditorCoreBase || class {};
  const withTranscript = global.TranscriptMixin
    ? global.TranscriptMixin(Base)
    : Base;
  const withProgress = global.ProgressMixin
    ? global.ProgressMixin(withTranscript)
    : withTranscript;
  const withHistory = global.HistoryMixin
    ? global.HistoryMixin(withProgress)
    : withProgress;
  const withSubtitles = global.SubtitlesMixin
    ? global.SubtitlesMixin(withHistory)
    : withHistory;
  const withAlignment = global.EnhancedAlignmentMixin
    ? global.EnhancedAlignmentMixin(withSubtitles)
    : withSubtitles;

  class VideoEditorCoreExt extends withAlignment {
    constructor(appRef) {
      super(appRef);
      // Late bindings
      this.initTranscriptBindings && this.initTranscriptBindings();
      // Provide minimal public methods expected by other scripts
      if (!this.previewWithSubtitles) {
        this.previewWithSubtitles = () => {
          // placeholder - extensions (overlay) will hook timeupdate anyway
        };
      }
      console.log("[VideoEditorCoreExt] Modular core ready");
    }
  }
  global.VideoEditorCoreExt = VideoEditorCoreExt;
})(window);
