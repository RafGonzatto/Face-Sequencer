// core_progress.js - progress overlay management
(function (global) {
  function ProgressMixin(Base) {
    return class extends Base {
      _createProgressOverlay(message) {
        if (document.getElementById("videoGenProgressOverlay")) return;
        const host = this.videoPreview?.parentElement || document.body;
        const ov = document.createElement("div");
        ov.id = "videoGenProgressOverlay";
        ov.style.cssText =
          "position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;background:rgba(0,0,0,.55);color:#fff;font:14px system-ui,sans-serif;z-index:80;padding:16px;gap:10px;text-align:center;";
        ov.innerHTML = `<div style="font-size:15px">${
          message || "Processando..."
        }</div><div id="phaseProgressBar" style="width:60%;height:8px;background:rgba(255,255,255,.2);border-radius:4px;overflow:hidden"><div id="phaseProgressInner" style="height:100%;width:0%;background:#3b82f6;transition:width .25s ease"></div></div><div id="genProgressDetail" style="font-size:11px;opacity:.8"></div>`;
        host.appendChild(ov);
      }
      _removeProgressOverlay() {
        const o = document.getElementById("videoGenProgressOverlay");
        if (o) o.remove();
      }
      _updateProgressDetail(txt) {
        const el = document.getElementById("genProgressDetail");
        if (el) el.textContent = txt;
      }
      _updatePhaseProgress(pct) {
        const inner = document.getElementById("phaseProgressInner");
        if (inner)
          inner.style.width = Math.min(100, Math.max(0, pct || 0)) + "%";
      }
      _updateTokenCounter() {
        /* placeholder */
      }
    };
  }
  global.ProgressMixin = ProgressMixin;
})(window);
