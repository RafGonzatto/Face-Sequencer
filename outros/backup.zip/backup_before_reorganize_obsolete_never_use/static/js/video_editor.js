// video_editor.js (shim) - delegates to modular implementation served from ./video_editor_mod
// Keeps global window.VideoEditorModule for existing script references.
console.log(
  "🎬 Loading VideoEditorModule (shim -> served modular implementation)..."
);
(function initModular() {
  if (window.VideoEditorModule && window.__VIDEO_EDITOR_MODULAR_LOADED__)
    return;
  try {
    // Import from a path guaranteed to be under static/js that the server actually serves.
    import("./video_editor_mod/index.js")
      .then((mod) => {
        if (mod && mod.VideoEditorModule) {
          window.VideoEditorModule = mod.VideoEditorModule;
          window.__VIDEO_EDITOR_MODULAR_LOADED__ = true;
          console.log("✅ VideoEditorModule (modular) ready");
          try {
            window.dispatchEvent(new CustomEvent("VideoEditorModuleReady"));
          } catch (_) {}
        } else {
          console.error("❌ Modular VideoEditorModule export missing");
        }
      })
      .catch((err) =>
        console.error("❌ Failed to load modular VideoEditorModule", err)
      );
  } catch (e) {
    console.error(
      "❌ Dynamic import unsupported for VideoEditorModule shim",
      e
    );
  }
})();
